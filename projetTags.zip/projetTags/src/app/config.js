
export default {
  firebase: {
    apiKey: "AIzaSyAmbnhy3yKu3e8Y0_a_gNhd8doqTPULsjw",
    authDomain: "ionic-qr-tags.firebaseapp.com",
    databaseURL: "https://ionic-qr-tags.firebaseio.com",
    projectId: "ionic-qr-tags",
    storageBucket: "ionic-qr-tags.appspot.com",
    messagingSenderId: "317805455095"
  }
};
