import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {FirebaseProvider} from "../../providers/firebase/firebase";

/**
 * Generated class for the ListTagsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-list-tags',
  templateUrl: 'list-tags.html',
})
export class ListTagsPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, public firebase: FirebaseProvider) {
    console.log(this.getTags())
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ListTagsPage');
  }

  getTags() {
    return this.firebase.getTags();
  }

}
