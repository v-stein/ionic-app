import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ListTagsPage } from './list-tags';

@NgModule({
  declarations: [
    ListTagsPage,
  ],
  imports: [
    IonicPageModule.forChild(ListTagsPage),
  ],
})
export class ListTagsPageModule {}
