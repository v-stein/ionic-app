import { Component } from '@angular/core';
import {AlertController, NavController} from 'ionic-angular';
import {FirebaseProvider} from "../../providers/firebase/firebase";
import {ListTagsPage} from "../list-tags/list-tags";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  email: string;
  password: string;

  constructor(public navCtrl: NavController, public firebase: FirebaseProvider, public alertCtrl: AlertController) {

  }

  loginUser () {
    this.firebase.loginUser(this.email, this.password).then(() => {
      this.navCtrl.push(ListTagsPage);
    }).catch(err => {
      let alert = this.alertCtrl.create({
        title: 'Error',
        subTitle: err.message,
        buttons: ['OK']
      });
      alert.present();
    });
  }

}
