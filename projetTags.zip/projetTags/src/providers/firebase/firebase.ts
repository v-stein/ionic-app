import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import firebase from 'firebase';
import config from '../../app/config';

/*
  Generated class for the FirebaseProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class FirebaseProvider {

  firestore: any;

  constructor(public http: HttpClient) {
    firebase.initializeApp(config.firebase);
    this.firestore = firebase.firestore();
    this.firestore.settings({ timestampsInSnapshots: true });
  }

  loginUser (email, password) {
    return firebase.auth().signInWithEmailAndPassword(email, password);
  }

  getTags () {
    return this.firestore.collection('tags').get();
  }

}
